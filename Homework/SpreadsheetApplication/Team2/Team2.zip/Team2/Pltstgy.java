import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.LinkedHashMap;
import java.util.Map;
interface Pltstgy{
	public void print(LinkedHashMap<String,Data> data_list);
	public void modify();
}