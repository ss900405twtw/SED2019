public class Data
{
	public int value;

	Data(int value) {
		this.value = value;
	}

}