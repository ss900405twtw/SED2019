import java.util.ArrayList;

public class Line {
    public ArrayList<Component> components;
    public Line(){
        // System.out.println("Create a line");
        this.components = new ArrayList<Component>();
    }
}
